---
title: Book half
categories:
  - Real world
tags:
  - novel
  - read
  - magazine
---
