---
title: Dash circle
categories:
  - UI and keyboard
tags:
  - minus
---
